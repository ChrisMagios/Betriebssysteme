int main() {
  for (int i = 0; i < 50; i++)
    usleep(10);
}
