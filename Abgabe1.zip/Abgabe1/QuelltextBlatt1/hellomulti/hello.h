#pragma once

int hello();
