#include "hello.h"

#include <stdio.h>

int hello() {
	printf("Hello World from Hellomulti!\n");
	return 0;
}
